package com.wisdom.framework.sharding.mapper;

import com.wisdom.framework.sharding.entity.OrderItem;

public interface OrderItemMapper {

    int insertOrderItem(OrderItem orderItem);
}
