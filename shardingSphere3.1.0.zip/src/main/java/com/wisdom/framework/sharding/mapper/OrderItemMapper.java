package com.wisdom.framework.sharding.mapper;

public interface OrderItemMapper {
}
